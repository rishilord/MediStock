# Build MedStock APK without a PC

## Recommended: GitHub Actions

1. Create/sign in to a GitHub account.
2. Create a new repository, e.g. `MedStock`.
3. Upload **all files and folders inside this project** to the repository (not the ZIP file itself).
4. Open the repository's **Actions** tab.
5. Select **Build MedStock APK**.
6. Press **Run workflow**.
7. When the run finishes, open the completed run and download the artifact named **MedStock-debug-apk**.
8. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.
9. Send/open that APK on your Android phone and install it. If Android blocks it, allow installation from that source in Android settings.

## Important

This starter is a debug APK for testing, not a Play Store release. It currently keeps inventory only in app memory, so data resets after the app process is recreated. A production version should add Room persistence, expiry/low-stock notifications, backup/export, and a signed release build.

## If using a cloud IDE

Import the project into an Android-compatible cloud development environment, use JDK 17 and Gradle 8.10, then run:

`gradle assembleDebug`

APK output:

`app/build/outputs/apk/debug/app-debug.apk`
