# MedStock — Android starter app

A simple offline-first medicine inventory UI with:
- Dashboard
- Medicine/batch/quantity/expiry fields
- Search
- Low-stock count
- Delete items
- Add-medicine dialog

## Build
Open the project in Android Studio, let Gradle sync, then Run on an Android device/emulator.

The current version uses sample in-memory data. The next production step is replacing it with Room persistence and WorkManager expiry/low-stock notifications.
