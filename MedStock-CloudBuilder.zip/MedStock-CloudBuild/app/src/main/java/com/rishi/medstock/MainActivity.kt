package com.rishi.medstock

import android.app.*
import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

data class Medicine(
    val id: Long,
    val name: String,
    val batch: String,
    val quantity: Int,
    val expiry: String
)

class InventoryViewModel : ViewModel() {
    private val _items = mutableStateListOf<Medicine>()
    val items: List<Medicine> get() = _items

    init {
        _items.addAll(listOf(
            Medicine(1, "Paracetamol 500mg", "B2401", 120, "12/2027"),
            Medicine(2, "Amoxicillin 500mg", "A1198", 35, "03/2027"),
            Medicine(3, "ORS", "O8821", 8, "01/2027")
        ))
    }

    fun add(name: String, batch: String, qty: Int, expiry: String) {
        _items.add(Medicine(System.currentTimeMillis(), name, batch, qty, expiry))
    }
    fun delete(m: Medicine) { _items.remove(m) }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MedStockApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MedStockApp(vm: InventoryViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(title = {
                    Column {
                        Text("MedStock", fontWeight = FontWeight.Bold)
                        Text("Medicine Inventory", style = MaterialTheme.typography.labelSmall)
                    }
                })
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(tab == 0, { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                    NavigationBarItem(tab == 1, { tab = 1 }, icon = { Icon(Icons.Default.Search, null) }, label = { Text("Stock") })
                }
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }) {
                    Icon(Icons.Default.Add, "Add medicine")
                }
            }
        ) { pad ->
            if (tab == 0) Dashboard(vm.items, Modifier.padding(pad))
            else StockScreen(vm.items, search, { search = it }, { vm.delete(it) }, Modifier.padding(pad))
        }

        if (showAdd) {
            AddMedicineDialog(
                onDismiss = { showAdd = false },
                onAdd = { n,b,q,e -> vm.add(n,b,q,e); showAdd = false }
            )
        }
    }
}

@Composable
fun Dashboard(items: List<Medicine>, modifier: Modifier = Modifier) {
    val total = items.sumOf { it.quantity }
    val low = items.count { it.quantity <= 10 }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Dashboard", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Medicines", items.size.toString(), Modifier.weight(1f))
            StatCard("Total stock", total.toString(), Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        StatCard("Low stock", low.toString(), Modifier.fillMaxWidth())
        Spacer(Modifier.height(24.dp))
        Text("Recent stock", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        items.take(5).forEach { MedicineRow(it, {}) }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun StockScreen(items: List<Medicine>, search: String, onSearch: (String) -> Unit, onDelete: (Medicine) -> Unit, modifier: Modifier = Modifier) {
    val filtered = items.filter { it.name.contains(search, true) || it.batch.contains(search, true) }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(search, onSearch, Modifier.fillMaxWidth(), label = { Text("Search medicine or batch") }, singleLine = true)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered, key = { it.id }) { m -> MedicineRow(m) { onDelete(m) } }
        }
    }
}

@Composable
fun MedicineRow(m: Medicine, onDelete: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(m.name, fontWeight = FontWeight.Bold)
                Text("Batch: ${m.batch}  •  Exp: ${m.expiry}")
                Text("Qty: ${m.quantity}", fontWeight = FontWeight.SemiBold)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Delete") }
        }
    }
}

@Composable
fun AddMedicineDialog(onDismiss: () -> Unit, onAdd: (String,String,Int,String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var batch by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("") }
    var expiry by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add medicine") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Medicine name") }, singleLine = true)
                OutlinedTextField(batch, { batch = it }, label = { Text("Batch number") }, singleLine = true)
                OutlinedTextField(qty, { qty = it.filter(Char::isDigit) }, label = { Text("Quantity") }, singleLine = true)
                OutlinedTextField(expiry, { expiry = it }, label = { Text("Expiry (MM/YYYY)") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank() && qty.toIntOrNull() != null, onClick = {
                onAdd(name.trim(), batch.trim(), qty.toInt(), expiry.trim())
            }) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
